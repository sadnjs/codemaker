﻿namespace 코드발급기
{
    internal class Data
    {
        public string Code1 { get; set; }
    }
}
